x = pi:0.01:pi;
y = cos(x);
plot(x,y);
xlabel('y=cos(x)');
ylabel('y=cos(x)');
title('Graph of cosine from -pi to pi');