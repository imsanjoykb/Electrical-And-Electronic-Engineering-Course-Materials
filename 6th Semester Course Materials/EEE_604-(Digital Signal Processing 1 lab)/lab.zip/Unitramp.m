n= 10;
t=0:1:n-1;
subplot(2,2,3);
stem(t,t);
ylabel('Amplitude');
xlabel('unit ramp');